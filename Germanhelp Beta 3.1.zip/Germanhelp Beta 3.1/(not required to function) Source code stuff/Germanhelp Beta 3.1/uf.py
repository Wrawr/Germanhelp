import json
import os
from termcolor import cprint
# Usefull functions
def read_json_dictionaries(folder_name="Lists"):
    """
    Reads all .json files in the specified folder and returns their content 
    as a dictionary with file names as keys and file contents as values.
    
    Args:
        folder_name (str): The folder containing the JSON files (default is "Lists").
    
    Returns:
        dict: A dictionary where keys are file names (without extension) and 
              values are the dictionaries read from the files.
    """
    result = {}
    
    # Get the absolute path of the folder
    folder_path = os.path.abspath(folder_name)
    
    # Check if the folder exists
    if not os.path.exists(folder_path):
        raise FileNotFoundError(f"The folder '{folder_name}' does not exist.")
    
    # Iterate through all files in the folder
    for file_name in os.listdir(folder_path):
        # Only process files with the .json extension
        if file_name.endswith('.json'):
            file_path = os.path.join(folder_path, file_name)
            try:
                with open(file_path, 'r', encoding='utf-8') as json_file:
                    # Load the JSON file content
                    data = json.load(json_file)
                    # Ensure the content is a dictionary
                    if isinstance(data, dict):
                        # Use the file name without the extension as the key
                        key = os.path.splitext(file_name)[0]
                        result[key] = data
                    else:
                        print(f"Warning: The file '{file_name}' does not contain a dictionary. Skipping.")
            except (json.JSONDecodeError, IOError) as e:
                print(f"Error reading file '{file_name}': {e}")
    
    return result

def write(file_path, data, file_format="json"):
    """
    Writes data to the specified file in a (sub)folder.
    Automatically creates folders if they do not exist.
    
    :param file_path: The path to the file (including subfolders and file name).
    :param data: The data to write. It can be a string, list, dictionary, etc.
    :param file_format: The format to save the file in ("json", "txt"). Default is "json".
    """
    # Ensure the directory exists by extracting folder path and creating it if needed
    folder = os.path.dirname(file_path)
    if not os.path.exists(folder):
        os.makedirs(folder)

    # Write data based on the file format
    with open(file_path, "w") as file:
        if file_format == "json":
            if isinstance(data, (dict, list)):
                json.dump(data, file, indent=4)
            else:
                raise ValueError("Data must be a dictionary or list for JSON format.")
        elif file_format == "txt":
            file.write(str(data))
        else:
            raise ValueError("Unsupported file format. Use 'json' or 'txt'.")
def read(file_path, file_format="json"):
    """
    Reads data from the specified file in a (sub)folder.
    
    :param file_path: The path to the file (including subfolders and file name).
    :param file_format: The format of the file ("json", "txt"). Default is "json".
    :return: The data read from the file.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file {file_path} does not exist.")
    
    # Read the file based on the file format
    with open(file_path, "r") as file:
        if file_format == "json":
            return json.load(file)  # Returns a dictionary or list
        elif file_format == "txt":
            return file.read()  # Returns the content as a string
        else:
            raise ValueError("Unsupported file format. Use 'json' or 'txt'.")
def save_slot_exists(slot_name):
    """
    Checks if a given saveslot exists in the "Saves" folder

    :param slot_name: The save slots name
    """
    # Define the path to the save slot folder
    save_slot_path = os.path.join("Saves", slot_name)
    
    # Check if the folder exists
    return os.path.isfile(save_slot_path)
def create_save_slot(Default_Values: dict):
        """
        Creates a save slot in a folder called "Saves"

        :param Default_Values: A dictionary with the default to use when starting
        """
        cprint("Please enter the name of the save you want to create","dark_grey")
        oc = str(input())
        current_save_slot = f"{oc}.json"
        write(f"Saves/{current_save_slot}",Default_Values)
        cprint(f"Succesfully created new save {current_save_slot[:-5]}","green")
        print()
def load_save_slot(folder_name,list_name):
        """
        Loads the specified save slot

        :param save_slot: The save slot to load
        :return: The saves data
        """
        Save = read(f"{folder_name}/{list_name}")
        cprint(f"Selected save slot {list_name[:-5]}","dark_grey")
        print()
        return(Save)
def save_slot_function(Default_Values: dict):
    """
    Makes the user create/load a save slot and returns its save data

    :param Default_Values: The default values to use when starting
    :return: A tuple with the save data and the save files name
    """
    while True:
        cprint("Please select a save, type newsave to create a new save","dark_grey")
        oc = str(input())
        print()
        if oc == "newsave":
            create_save_slot(Default_Values)
        else:
            current_save_slot = f"{oc}.json"
            if save_slot_exists(current_save_slot) == True:
                Save_Data = load_save_slot(current_save_slot)
                break
            else:
                cprint("Error: That save slot does not exist, maybe you made a type error?","red")
    return current_save_slot, Save_Data
def save(Save_Slot,Save_Data):
    """
    Saves data to a save file in a "Saves" folder

    :param Save_Slot: The name of the save slot
    :param Save_Data: The data to store
    """
    write(f"Saves/{Save_Slot}",Save_Data)
    cprint("Saved succesfully!","green")
def wipesavedata(Save_Slot_To_Wipe,Default_Values: dict):
    """
    Wipes the save with a warning

    :param Save_Slot_To_Wipe: The save slot you want to wipe
    :param Default_Values: The values to reset the save to
    """
    cprint("WARNING THIS IS NOT REVERTIBLE, ONLY DO THIS IF YOU ARE ABSOLUTELY SURE YOU WANT TO DO THIS. TYPE IamREALLYsure to continue","red")
    oc = str(input())
    if oc == "IamREALLYsure":
        write(f"Saves/{Save_Slot_To_Wipe}",Default_Values)
        cprint("Save data reset","dark_grey")
def sinput(String,Color):
    cprint(String,Color)
    return(input())