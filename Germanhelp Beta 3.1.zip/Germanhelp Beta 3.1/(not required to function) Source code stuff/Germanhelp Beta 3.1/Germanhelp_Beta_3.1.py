# Importing modules
import random
from termcolor import cprint, colored
from uf import *

# Setting default values
correct_answers = 0
session_correct_answers = 0
incorrect_answers = 0
session_incorrect_answers = 0

# Loading lists
lists = read_json_dictionaries()
# Defining functions

# Function to test the list
def test_list(selected_list,first_word_to_practice,last_word_to_practice):
    current_list = dict(lists[selected_list])
    rfwtp = first_word_to_practice + 1
    rlwtp = last_word_to_practice + 2
    index = first_word_to_practice
    keys = []
    values = []
    correct_answers = 0
    incorrect_answers = 0
    language = list(current_list.values())[0]
    lwtp2 = last_word_to_practice + 2
    while True:
        current_key = list(current_list.keys())[index]
        current_value = list(current_list.values())[index]
        if index in range(rfwtp,rlwtp):
            keys.append(current_key)
            values.append(current_value)
        index += 1
        if index >= lwtp2:
            current_list = dict(zip(keys,values))
            current_list = list(current_list.items())
            random.shuffle(current_list)
            current_list = dict(current_list)
            break
    for word in list(current_list.keys()):
        correct_answer = current_list[word]
        cprint(f"What is {colored(word,'light_cyan')} {colored('in','dark_grey')} {colored(language,'dark_grey')} {colored('?','dark_grey')}","dark_grey")
        answer = input()
        print()
        if answer == correct_answer:
            correct_answers += 1
            cprint("Correct!","light_green")
            print()
        elif answer == "stop":
            break
        else:
            cprint(f"Sorry that was incorrect, the correct answer was: {colored(correct_answer,'red')}","light_red")
            print()
            incorrect_answers += 1
    return([correct_answers,incorrect_answers])
while True:
    session_correct_answers = correct_answers
    correct_answers = 0
    session_incorrect_answers = incorrect_answers
    incorrect_answers = 0
    cprint("What do you want to practice?","dark_grey")
    print()
    list_chosen_str_name = str(input())
    print()
    if list_chosen_str_name == "help":
        cprint("Available lists:","light_cyan")
        for list in lists:
            cprint(f"- {list}","dark_grey")
        print()
    else:
        if list_chosen_str_name in lists:
            list_chosen = dict(lists[list_chosen_str_name])
            cprint(f"Chose list {str(list_chosen_str_name)}.","dark_grey")
            cprint("Special characters: öüäß","dark_grey")
            print()
            cprint("What is the first word you would like to practice? (input a positive integer)","dark_grey")
            try:
                first_word_to_practice = int(input())
            except ValueError:
                cprint("Input is not valid: Not an integer, setting input to 1","light_red")
                first_word_to_practice = 1
            if first_word_to_practice < 1:
                cprint("Input is not valid: Less than 1, setting input to 1","light_red")
                first_word_to_practice = 1
            print()
            cprint(f"What is the last word you want to practice? (max {len(list_chosen)})","dark_grey")
            try:
                last_word_to_practice = int(input())
            except ValueError:
                cprint("Input is not valid: Not an integer, setting input to first word to practice + 1","light_red")
                last_word_to_practice = first_word_to_practice + 1
            if first_word_to_practice > last_word_to_practice:
                cprint("Input is not valid: Last word to practice cannot be higher than first word to practice, setting input to first word to practice + 1","light_red")
                last_word_to_practice = first_word_to_practice + 1
            if last_word_to_practice > len(list_chosen):
                cprint("Input is not valid: Cannot be higher than list length, setting input to list lenght","light_red")
                last_word_to_practice = len(list_chosen)
            test_output = test_list(list_chosen_str_name,first_word_to_practice-1,last_word_to_practice-1)
            correct_answers = test_output[0]
            incorrect_answers = test_output[1]
            if incorrect_answers == 0:
                test_grade = 10
            else:
                test_grade = round((correct_answers/(correct_answers+incorrect_answers))*10,1)
            cprint(f"You had {correct_answers} correct answers and {incorrect_answers} incorrect answers ({test_grade})","dark_grey")
        else:
            cprint(f"Invalid list '{list_chosen_str_name}'. Maybe you made a spelling mistake? (input help for available lists)","light_red")