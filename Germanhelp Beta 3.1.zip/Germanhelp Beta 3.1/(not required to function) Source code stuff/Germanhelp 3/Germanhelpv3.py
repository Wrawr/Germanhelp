import random
from termcolor import colored, cprint
#Chapter 1
dutch_word_list_A = ["zonder meer, per se","elkaar, wederzijds","solliciteren","achteraf","onderzoeken","van gedachten wisselen","het eens zijn","elkaar aanvullen","zelfstandig","de prestatie","het verlangen","desondanks","vaak","de afstand","het welzijn","verminderen","het effect","de beslissing"]
german_word_list_A = ["unbedingt","gegenseitig","sich bewerben","im Nachhinein","forschen","sich austauschen","sich einig sein","sich ergänzen","eigenständig","die Leistung","die Sehnsucht","Trotzdem","häuftig","die Entfernung","das Wohlbefinden","verringern","die Wirkung","die Entscheidung"]
dutch_word_list_B = ["onlangs","toen, destijds","voortdurend","nauwelijks","oppervlakkig","de waardering","per se","de afstand","lukken","op de hoogte houden","scheiden, uit elkaar gaan","verhuizen","stichten","de opvang, de verzorging","rekening houden met"]
german_word_list_B = ["neulich","damals","ständig","kaum","oberflächlich","die Wertschätzung","unbedingt","die Entfernung","klappen","auf dem Laufenden halten","sich trennen","ausziehen","gründen","die Betreeung","Rücksicht nehmen auf"]
dutch_word_list_D1 = ["het bezoek","het familielid","de humor","de kus","de mentor","de partner","de afspraak","het bericht","de relatie","de sfeer","het gesprek","de interesse","de ontmoeting","de verhouding","afgesproken hebben met","blij zijn","elkaar leren kennen","familie zijn van","goed humeur hebben","iets gemeenschappelijk hebben","krijgen","kunnen opschieten met","ontmoeten","samenwonen"]
german_word_list_D1 = ["der Besuch","der Verwandte","der Humor","der Kuss","der Klassenlehrer","der Partner","die Verabredung","die Nachricht","die Beziehung","die Stimmung","das Gespräch","das Interesse","das Treffen","das Verhältnis","verabredet sein mit","sich freuen","sich kennenlernen","verwandt sein mit","gute Laune haben","etwas gemeinsam haben","bekommen","sich verstehen mit","sich treffen","zusammenleben"]
dutch_word_list_D2 = ["scheiden","spijten","trouwen","verliefd worden op","zoenen","bekend","beleefd","bevriend","gelukkig","gênant","gescheiden","getrouwd","grappig","jammer","moedig","slank","stom","sympathiek","trots","verdrietig","verschrikkelijk","zenuwachtig","al","echt","hetzelfde, dezelfde","hoewel","in ieder geval","toch","misschien","pas","tijdens, terwijl","toevallig","vast, beslist","zeker","zelfs"]
german_word_list_D2 = ["sich scheiden lassen","leidtun - leidgetan","heiraten","sich verlieben in","sich küssen","bekannt","höflich","befreundet","glücklich","peinlich","geschieden","verheiratet","lustig","schade","mutig","schlank","doof","sympatisch","stolz","traurig","schreiklich","aufgeregt","schon","wirklich, echt","dieselbe, dasselbe, derselbe","obwohl","auf jeden Fall","ja","vielleicht","erst","während","zufällig","bestimmt","sicher","sogar"]
dutch_word_list_G = ["geleden","volgens","anders","met betrekking tot","het gat"]
german_word_list_G = ["vor","laut","sonst","in Bezug auf","die Lücke"]
dutch_word_list_F = ["de mislukking, flop","ambitieus","falen, mislukken","iets halen, voor elkaar krijgen","zich niet klein laten krijgen","teleurgesteld","(voor een examen) zakken","zich helemaal down voelen","genant","de outsider"]
german_word_list_F = ["die Misserfolg","ehrgeizig","scheitern","etwas schaffen","sich nicht unterkriegen lassen","enttäuscht","durchfallen","am Boden zerstört sein","peinlich","der Außenseiter"]
dutch_word_list_I1 = ["het compromis","de ruzie","het standpunt","de vent, de kerel","de volwassene","de oplossing","aanbieden","adviseren","bedoelen","beledigen","discussieren met ... over","durven","elkaar omhelzen","enthousiast over iets zijn","geloven in","het (on)eens zijn","het uitmaken","langskomen bij","met elkaar afspreken over","met 'je' aanspreken","met 'u' aanspreken","noemen","overhalen","overtuigen","reageren"]
german_word_list_I1 = ["der Kompromiss","der Streit","der Standpunkt","der Typ","der Erwaschene","die Lösung","aanbieten","raten","meinen","beleidigen","diskutieren mit ... über","sich trauen","sich umarmen","von etwas begeistert sein","glauben an","(nicht) einverstanden sein","Schluss maken","vorbeikommen bei","sich unterhalten über","duzen","siezen","nennen","überreden","überzeugen","reagieren"]
dutch_word_list_I2 = ["ruzie maken","van mening zijn","vertrouwen","verwachten","wennen aan","zich iets voorstellen","belangrijk","handig","kort, korter","lang langer","nieuwschierig","teleurgesteld","trouwens","als, indien","bovendien","Dat klopt.","desondanks","dus","helaas","nadat","of (als voegwoord)","samen","gemeenschappelijk","tenslotte","toen","volgens mij","voortdurend","want, dan"]
german_word_list_I2 = ["sich streiten","der Meinung sein","vertrauen","erwarten","sich gewöhnen an","sich etwas vorstellen","wichtig","praktisch","kurz, kürzer","lang, länger","neugierig","enttäuscht","übrigens","wenn","außerdem","Das stimmt.","trotzdem","also","leider","nachdem","ob","zusammen","gemeinsam","schließlich","als","meiner Meinungnach","ständig","denn"]
hsw = ["habe","hast","hat","haben","habt","haben","bin","bist","ist","sind","seid","sind","werde","wirst","wird","werden","werdet","werden"]
wdi = ["ich (haben)","du (haben)","er/sie/es (haben)","wir (haben)","ihr (haben)","sie/Sie (haben)","ich (sein)","du (sein)","er/sie/es (sein)","wir (sein)","ihr (sein)","sie/Sie (sein)","ich (werden)","du (werden)","er/sie/es (werden)","wir (werden)","ihr (werden)","sie/Sie (werden)"]
#chapter 2
hww = ["kann","kannst","können","könnt","darf","darfst","dürfen","dürft","mag","magst","mögen","mögt","möchte","möchtest","möchten","möchtet","muss","musst","müssen","müsst","soll","sollst","sollen","sollt","will","willst","wollen","wollt","weiß","weißt","wissen","wisst"]
type = ["ich/er/sie/es/mann (können)","du (können)","wir/sie/Sie (können)","ihr (können)","ich/er/sie/es/mann (dürfen)","du (dürfen)","wir/sie/Sie (dürfen)","ihr (dürfen)","ich/er/sie/es/mann (mögen)","du (mögen)","wir/sie/Sie (mögen)","ihr (mögen)","ich/er/sie/es/mann (möchten)","du (möchten)","wir/sie/Sie (möchten)","ihr (möchten)","ich/er/sie/es/mann (müssen)","du (müssen)","wir/sie/Sie (müssen)","ihr (müssen)","ich/er/sie/es/mann (sollen)","du (sollen)","wir/sie/Sie (sollen)","ihr (sollen)","ich/er/sie/es/mann (wollen)","du (wollen)","wir/sie/Sie (wollen)","ihr (wollen)","ich/er/sie/es/mann (wissen)","du (wissen)","wir/sie/Sie (wissen)","ihr (wissen)",]
cprint("Welcome back!","light_blue")
print()
def Multichoice(listfrom,listto,lang):
    cwt = order[Words_practiced]
    oa = listto[cwt]
    ob = listto[order2[Words_practiced]]
    xoc = listto[order3[Words_practiced]]
    od = listto[order4[Words_practiced]]
    d = 0
    i = 1
    while True:
        if oa == ob:
            d = 0
            oa = listto[cwt+i]
        elif oa == xoc:
            d = 0
            oa = listto[cwt+i]
        elif oa == od:
            d = 0
            oa = listto[cwt+i]
        elif ob == xoc:
            d = 0
            ob = listto[order2[Words_practiced+i]]
        elif ob == od:
            d = 0
            ob = listto[order2[Words_practiced+i]]
        elif xoc == od:
            d = 0
            ob = listto[order3[Words_practiced+i]]
        break
    options = [oa,ob,xoc,od]
    random.shuffle(options)
    lang = colored(lang,"dark_grey")
    selected_word = colored(listfrom[cwt],"light_blue")
    correct_answer = listto[cwt]
    #coloring text
    cprint1 = colored("what is","dark_grey")
    cprint2 = colored("in","dark_grey")
    cprint3 = colored("?","dark_grey")
    print(cprint1,selected_word,cprint2,lang,cprint3)
    cprint("Options:","dark_grey")
    for x in options:
        cprint(x,"light_blue")
    print()
    answer = input()
    if answer == correct_answer:
        print()
        random_correct_answer = ["Great job!","Correct!","Well done!"]
        random.shuffle(random_correct_answer)
        random_correct_answer = random_correct_answer[1]
        cprint(random_correct_answer,"light_green")
        print()
        return("Correct")
    elif answer == "stop":
        return("Stop")
    else:
        print()
        cprint1 = colored("Sorry that was incorrect, the correct answer was:","red")
        correct_answer = colored(correct_answer,"light_red")
        print(cprint1,correct_answer)
        print()
        return("Incorrect")  
def Test(listfrom,listto,lang):
    cwt = order[Words_practiced]
    lang = colored(lang,"dark_grey")
    selected_word = colored(listfrom[cwt],"light_blue")
    correct_answer = listto[cwt]
    #coloring text
    cprint1 = colored("what is","dark_grey")
    cprint2 = colored("in","dark_grey")
    cprint3 = colored("?","dark_grey")
    print(cprint1,selected_word,cprint2,lang,cprint3)
    answer = input()
    if answer == correct_answer:
        print()
        random_correct_answer = ["Great job!","Correct!","Well done!"]
        random.shuffle(random_correct_answer)
        random_correct_answer = random_correct_answer[1]
        cprint(random_correct_answer,"light_green")
        print()
        return("Correct")
    elif answer == "stop":
        return("Stop")
    else:
        print()
        cprint1 = colored("Sorry that was incorrect, the correct answer was:","red")
        correct_answer = colored(correct_answer,"light_red")
        print(cprint1,correct_answer)
        print()
        return("Incorrect")
def wordlistsoftcodingthing(listfrom,listto,language):
    #softcoded order var
    print()
    cprint("Type m if you want to practice multichoice","dark_grey")
    oc = input()
    print()
    if oc == "m":
        multichoice = 1
    else:
        multichoice = 0
    orderamount = len(listfrom)
    global Words_practiced
    Words_practiced = 0
    global orderthing
    orderthing = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70.71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100]
    current_orderthing = 0
    global order
    global order2
    global order3
    global order4
    order = []
    order2 = []
    order3 = []
    order4 = []
    for x in orderthing:
        if current_orderthing == orderamount:
            break
        order = order + [x]
        order2 = order2 + [x]
        order3 = order3 + [x]
        order4 = order4 + [x]
        current_orderthing = current_orderthing + 1
    random.shuffle(order)
    random.shuffle(order2)
    random.shuffle(order3)
    random.shuffle(order4)
    Correct_Answers = 0
    Incorrect_Answers = 0
    amount_to_practice = len(order)
    cprint1 = colored("You had","dark_grey")
    cprint2 = colored("correct answer(s) and","dark_grey")
    cprint3 = colored("incorrect answer(s) (","dark_grey")
    cprint4 = colored("%)","dark_grey")
    while True:
        if multichoice == 1:
            answer = Multichoice(listfrom,listto,language)
        else:
            answer = Test(listfrom,listto,language)
        if answer == "Stop":
            if Correct_Answers == 0:
                break
            Correct_Answer_Percantage = round((Correct_Answers/(Correct_Answers + Incorrect_Answers))*100,1)
            Correct_Answers = colored(Correct_Answers,"dark_grey")
            Incorrect_Answers = colored(Incorrect_Answers,"dark_grey")
            Correct_Answer_Percantage = colored(Correct_Answer_Percantage,"dark_grey")
            print(cprint1,Correct_Answers,cprint2,Incorrect_Answers,cprint3,Correct_Answer_Percantage,cprint4)
            print()
            break
        elif answer == "Correct":
            Correct_Answers = Correct_Answers + 1
        elif answer == "Incorrect":
            Incorrect_Answers = Incorrect_Answers + 1
        Words_practiced = Words_practiced + 1
        if Words_practiced == amount_to_practice:
            Correct_Answer_Percantage = round((Correct_Answers/(Correct_Answers + Incorrect_Answers))*100,1)
            Correct_Answers = colored(Correct_Answers,"dark_grey")
            Incorrect_Answers = colored(Incorrect_Answers,"dark_grey")
            Correct_Answer_Percantage = colored(Correct_Answer_Percantage,"dark_grey")
            print(cprint1,Correct_Answers,cprint2,Incorrect_Answers,cprint3,Correct_Answer_Percantage,cprint4)
            break
while True:
    cprint("What do you want to practice?","dark_grey")
    oc = input()
    if oc == "help":
        print()
        cprint("Special characters: öüäß","dark_grey")
        print()
        cprint("Possible Commands:","light_blue")
        cprint("help = shows you this list","dark_grey")
        cprint("A = V4 Neue kontakte list A","dark_grey")
        cprint("B = V4 Neue kontakte list B","dark_grey")
        cprint("D1 = V4 Neue kontakte list D page 1","dark_grey")
        cprint("D2 = V4 Neue kontakte list D page 2","dark_grey")
        cprint("I1 = V4 Neue kontakte list I page 1","dark_grey")
        cprint("I2 = V4 Neue kontakte list I page 2","dark_grey")
        cprint("F = V4 Neue kontakte list F","dark_grey")
        cprint("G = V4 Neue kontakte list G","dark_grey")
        cprint("HSW = Haben, sein and werden","dark_grey")
    elif oc == "A":
        wordlistsoftcodingthing(german_word_list_A,dutch_word_list_A,"Dutch")
    elif oc == "B":
        wordlistsoftcodingthing(german_word_list_B,dutch_word_list_B,"Dutch")
    elif oc == "D1":
        wordlistsoftcodingthing(dutch_word_list_D1,german_word_list_D1,"German")
    elif oc == "D2":
        wordlistsoftcodingthing(dutch_word_list_D2,german_word_list_D2,"German")
    elif oc == "I1":
        wordlistsoftcodingthing(dutch_word_list_I1,german_word_list_I1,"German")
    elif oc == "I2":
        wordlistsoftcodingthing(dutch_word_list_I2,german_word_list_I2,"German")
    elif oc == "F":
        wordlistsoftcodingthing(german_word_list_F,dutch_word_list_F,"Dutch")
    elif oc == "G":
        wordlistsoftcodingthing(german_word_list_G,dutch_word_list_G,"Dutch")
    elif oc == "HSW":
        wordlistsoftcodingthing(wdi,hsw,"its correct form")
    #chaper 2
    elif oc == "HWW":
        wordlistsoftcodingthing(type,hww,"its correct form")